# Cara build Cend Balloon (Flutter)

1. `flutter create --org com.cend --project-name cend_balloon .`  (di folder ini; file lib/ & pubspec tidak ditimpa kalau kamu jawab keep)
2. `flutter pub get`
3. Tambahkan ke `android/app/src/main/AndroidManifest.xml`:

   Di atas <application>:
   ```xml
   <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>
   <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
   ```
   Di dalam <application>:
   ```xml
   <service android:name="flutter.overlay.window.flutter_overlay_window.OverlayService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
     <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="floating balloon"/>
   </service>
   ```
4. Di `android/app/build.gradle` pastikan `minSdkVersion 23` (atau `flutter.minSdkVersion` >= 23).
5. Build untuk HP 32-bit & 64-bit sekaligus (satu APK):
   `flutter build apk --release --target-platform android-arm,android-arm64`
   atau per-arsitektur: `flutter build apk --release --split-per-abi`
6. Smooth 60/90/120 fps: Flutter otomatis ikut refresh rate layar. Selalu tes dengan `--release` (mode debug lambat).

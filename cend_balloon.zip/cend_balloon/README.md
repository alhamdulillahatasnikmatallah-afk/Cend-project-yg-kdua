# Cend Balloon (Cend Project) - Flutter

Balon dolphin pixel yang mengambang di layar. Dev stage.

Fitur: Pengaturan (tema putih-hitam / orange-putih), Device (model, Android, baterai real time),
Latihan Soal (skor vs target, jawab sendiri + pembahasan), Support Admin (QRIS).
Font pixel ala Flipper Zero, efek suara + getar di setiap klik.

## Build APK lewat GitHub (tanpa extract)

1. Buat repo baru di GitHub.
2. Upload file **cend_balloon.zip** ini ke root repo (jangan di-extract).
3. Buat file `.github/workflows/build.yml`, isi dengan file **build.yml** yang kamu terima.
   (GitHub -> Add file -> Create new file -> ketik nama `.github/workflows/build.yml`)
4. Commit. Buka tab **Actions** -> workflow "Build APK" jalan otomatis
   (atau klik **Run workflow**).
5. Setelah hijau, buka run-nya -> bagian **Artifacts** -> download **cend-balloon-apk**.

APK yang dihasilkan satu file universal (`armeabi-v7a` 32-bit + `arm64-v8a` 64-bit),
plus APK per-arsitektur.

## Cara pakai di HP
1. Install APK (izinkan "install dari sumber tidak dikenal").
2. Buka app -> tekan IZINKAN (izin tampil di atas aplikasi lain) -> AKTIFKAN BALON.
3. Ketuk balon untuk membuka menu. Geser balon untuk memindah.

## Mengganti soal Latihan Soal
Edit daftar `sampleQs` di `lib/main.dart`.

## Jika build gagal
Buka log step yang merah di tab Actions, lalu kirim log-nya untuk diperbaiki.

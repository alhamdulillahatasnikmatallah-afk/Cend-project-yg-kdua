"""Patch otomatis android/ hasil `flutter create` supaya balon overlay jalan."""
import re, pathlib, sys

root = pathlib.Path("android/app")
mf = root / "src/main/AndroidManifest.xml"
s = mf.read_text()

perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
"""
service = """        <service android:name="flutter.overlay.window.flutter_overlay_window.OverlayService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="floating balloon"/>
        </service>
"""
if "SYSTEM_ALERT_WINDOW" not in s:
    s = s.replace("<application", perms + "    <application", 1)
if "OverlayService" not in s:
    s = s.replace("</application>", service + "    </application>", 1)
# nama app
s = re.sub(r'android:label="[^"]*"', 'android:label="Cend Balloon"', s, count=1)
mf.write_text(s)

# minSdk 23 (Groovy / Kotlin DSL)
for name in ("build.gradle", "build.gradle.kts"):
    g = root / name
    if g.exists():
        t = g.read_text()
        t = t.replace("flutter.minSdkVersion", "23")
        t = re.sub(r"(minSdk(?:Version)?\s*=?\s*)\d+", r"\g<1>23", t)
        g.write_text(t)
        print("patched", g)
print("OK manifest patched")

import 'dart:async';
import 'package:battery_plus/battery_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:google_fonts/google_fonts.dart';

const kOrange = Color(0xFFFF8A2A);

TextStyle px(double size, Color c) =>
    GoogleFonts.pressStart2p(fontSize: size, color: c, height: 1.5);

final AudioPlayer _sfx = AudioPlayer()..setPlayerMode(PlayerMode.lowLatency);

void click() {
  () async {
    try {
      await _sfx.stop();
      await _sfx.play(AssetSource('sounds/click.wav'), volume: 1.0);
    } catch (_) {}
    try {
      await HapticFeedback.selectionClick();
    } catch (_) {}
  }();
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HomeApp());
}

/// Entry point untuk jendela balon (overlay)
@pragma("vm:entry-point")
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaterialApp(
      debugShowCheckedModeBanner: false, home: Material(color: Colors.transparent, child: BalloonRoot())));
}

// ───────────────────────── HOME ─────────────────────────
class HomeApp extends StatelessWidget {
  const HomeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool granted = false, active = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    granted = await FlutterOverlayWindow.isPermissionGranted();
    active = await FlutterOverlayWindow.isActive();
    if (mounted) setState(() {});
  }

  Future<void> _askPermission() async {
    click();
    await FlutterOverlayWindow.requestPermission();
    await _refresh();
  }

  Future<void> _toggle() async {
    click();
    if (!granted) return _askPermission();
    if (active) {
      await FlutterOverlayWindow.closeOverlay();
    } else {
      await FlutterOverlayWindow.showOverlay(
        height: 150,
        width: 150,
        alignment: OverlayAlignment.centerRight,
        enableDrag: true,
        flag: OverlayFlag.defaultFlag,
        positionGravity: PositionGravity.auto,
        overlayTitle: 'Cend Balloon',
        overlayContent: 'Balon aktif',
      );
    }
    await Future.delayed(const Duration(milliseconds: 300));
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            const Spacer(),
            Image.asset('assets/images/logo.png', width: 260),
            const SizedBox(height: 32),
            PixelButton(
                label: granted ? 'IZIN OK' : 'IZINKAN',
                color: granted ? Colors.black26 : Colors.black,
                onTap: granted ? () {} : _askPermission),
            const SizedBox(height: 16),
            PixelButton(
                label: active ? 'MATIKAN BALON' : 'AKTIFKAN BALON',
                color: kOrange,
                onTap: _toggle),
            const Spacer(),
            Text('project ini tahap pengembangan',
                textAlign: TextAlign.center, style: px(8, Colors.black54)),
          ]),
        ),
      ),
    );
  }
}

class PixelButton extends StatefulWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  const PixelButton({super.key, required this.label, required this.color, required this.onTap});
  @override
  State<PixelButton> createState() => _PixelButtonState();
}

class _PixelButtonState extends State<PixelButton> {
  bool down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTapDown: (_) => setState(() => down = true),
        onTapCancel: () => setState(() => down = false),
        onTapUp: (_) => setState(() => down = false),
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 70),
          transform: Matrix4.translationValues(0, down ? 4 : 0, 0),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 18),
          decoration: BoxDecoration(
            color: widget.color,
            border: Border.all(color: Colors.black, width: 3),
            boxShadow: down ? [] : const [BoxShadow(color: Colors.black, offset: Offset(0, 4))],
          ),
          child: Center(child: Text(widget.label, style: px(11, Colors.white))),
        ),
      );
}

// ───────────────────────── BALLOON OVERLAY ─────────────────────────
enum Pg { balloon, menu, settings, device, practice, support }

class BalloonRoot extends StatefulWidget {
  const BalloonRoot({super.key});
  @override
  State<BalloonRoot> createState() => _BalloonRootState();
}

class _BalloonRootState extends State<BalloonRoot> {
  Pg page = Pg.balloon;

  // tema 0 = putih/hitam, 1 = orange/putih
  int theme = 0;
  Color get bg => theme == 0 ? Colors.white : kOrange;
  Color get fg => theme == 0 ? Colors.black : Colors.white;

  Future<void> go(Pg p) async {
    click();
    if (p == Pg.balloon) {
      await FlutterOverlayWindow.updateFlag(OverlayFlag.defaultFlag);
      await FlutterOverlayWindow.resizeOverlay(150, 150, true);
    } else if (page == Pg.balloon) {
      await FlutterOverlayWindow.updateFlag(OverlayFlag.focusPointer);
      await FlutterOverlayWindow.resizeOverlay(330, 520, false);
    }
    setState(() => page = p);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 180),
      child: page == Pg.balloon ? _balloon() : _panel(),
    );
  }

  Widget _balloon() => GestureDetector(
        key: const ValueKey('b'),
        onTap: () => go(Pg.menu),
        child: Center(child: _Bob(child: Image.asset('assets/images/dolphin.png', width: 100))),
      );

  Widget _panel() {
    Widget body;
    switch (page) {
      case Pg.settings:
        body = _settings();
        break;
      case Pg.device:
        body = DeviceView(fg: fg);
        break;
      case Pg.practice:
        body = PracticeView(fg: fg, bg: bg);
        break;
      case Pg.support:
        body = _support();
        break;
      default:
        body = _menu();
    }
    return Container(
      key: const ValueKey('p'),
      margin: const EdgeInsets.all(6),
      decoration: BoxDecoration(color: bg, border: Border.all(color: fg, width: 3)),
      child: Column(children: [
        Container(
          color: fg,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: Row(children: [
            Expanded(child: Text('CEND PROJECT', style: px(9, bg))),
            GestureDetector(
              onTap: () => go(page == Pg.menu ? Pg.balloon : Pg.menu),
              child: Text(page == Pg.menu ? '[X]' : '[<]', style: px(10, bg)),
            ),
          ]),
        ),
        Expanded(child: Padding(padding: const EdgeInsets.all(12), child: body)),
      ]),
    );
  }

  Widget _item(String t, Pg p) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: GestureDetector(
          onTap: () => go(p),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(border: Border.all(color: fg, width: 2)),
            child: Text('> $t', style: px(9, fg)),
          ),
        ),
      );

  Widget _menu() => ListView(children: [
        _item('PENGATURAN', Pg.settings),
        _item('DEVICE', Pg.device),
        _item('LATIHAN SOAL', Pg.practice),
        _item('SUPPORT ADMIN', Pg.support),
      ]);

  Widget _settings() => ListView(children: [
        Text('WARNA LAYAR', style: px(9, fg)),
        const SizedBox(height: 12),
        _themeBtn('PUTIH - HITAM', 0),
        const SizedBox(height: 10),
        _themeBtn('ORANGE - PUTIH', 1),
        const SizedBox(height: 24),
        Text('project ini tahap pengembangan', style: px(8, fg)),
      ]);

  Widget _themeBtn(String t, int v) => GestureDetector(
        onTap: () {
          click();
          setState(() => theme = v);
        },
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              border: Border.all(color: fg, width: 2),
              color: theme == v ? fg : Colors.transparent),
          child: Text((theme == v ? '[x] ' : '[ ] ') + t, style: px(8, theme == v ? bg : fg)),
        ),
      );

  Widget _support() => ListView(children: [
        Text('support admin untuk menambah wawasan', textAlign: TextAlign.center, style: px(8, fg)),
        const SizedBox(height: 12),
        Container(color: Colors.white, padding: const EdgeInsets.all(6), child: Image.asset('assets/images/qris.jpeg')),
      ]);
}

/// animasi mengambang halus (GPU-friendly, ikut refresh rate layar 60/90/120Hz)
class _Bob extends StatefulWidget {
  final Widget child;
  const _Bob({required this.child});
  @override
  State<_Bob> createState() => _BobState();
}

class _BobState extends State<_Bob> with SingleTickerProviderStateMixin {
  late final AnimationController c =
      AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: c,
        child: widget.child,
        builder: (_, ch) => Transform.translate(
            offset: Offset(0, -6 * Curves.easeInOut.transform(c.value)), child: ch),
      );
}

// ───────────────────────── DEVICE ─────────────────────────
class DeviceView extends StatefulWidget {
  final Color fg;
  const DeviceView({super.key, required this.fg});
  @override
  State<DeviceView> createState() => _DeviceViewState();
}

class _DeviceViewState extends State<DeviceView> {
  final battery = Battery();
  String model = '...', android = '...', abi = '...';
  int level = 0;
  BatteryState state = BatteryState.unknown;
  Timer? t;
  StreamSubscription? sub;

  @override
  void initState() {
    super.initState();
    _load();
    _poll();
    t = Timer.periodic(const Duration(seconds: 2), (_) => _poll());
    sub = battery.onBatteryStateChanged.listen((s) => setState(() => state = s));
  }

  Future<void> _load() async {
    final i = await DeviceInfoPlugin().androidInfo;
    setState(() {
      model = '${i.manufacturer} ${i.model}';
      android = '${i.version.release} (API ${i.version.sdkInt})';
      abi = i.supportedAbis.isNotEmpty ? i.supportedAbis.first : '-';
    });
  }

  Future<void> _poll() async {
    final l = await battery.batteryLevel;
    if (mounted) setState(() => level = l);
  }

  @override
  void dispose() {
    t?.cancel();
    sub?.cancel();
    super.dispose();
  }

  Widget row(String k, String v) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(k, style: px(7, widget.fg.withOpacity(.6))),
          const SizedBox(height: 6),
          Text(v, style: px(9, widget.fg)),
        ]),
      );

  @override
  Widget build(BuildContext context) => ListView(children: [
        row('MODEL HP', model),
        row('ANDROID', android),
        row('BATERAI', '$level%  ${state.name}'),
        row('ARSITEKTUR', abi),
      ]);
}

// ───────────────────────── LATIHAN SOAL ─────────────────────────
class Q {
  final String q;
  final List<String> opts;
  final int ans;
  final String why;
  const Q(this.q, this.opts, this.ans, this.why);
}

// Ganti dengan soal buatanmu / ambil dari Cend Form
const sampleQs = [
  Q('2 + 2 x 3 = ?', ['12', '8', '10'], 1, 'Perkalian dikerjakan lebih dulu: 2 + 6 = 8.'),
  Q('Ibu kota Indonesia?', ['Jakarta', 'Bandung', 'Surabaya'], 0, 'Jakarta adalah ibu kota saat ini.'),
  Q('Air membeku pada suhu?', ['100 C', '0 C', '50 C'], 1, 'Titik beku air 0 derajat Celsius.'),
  Q('Hasil 15% dari 200?', ['30', '15', '45'], 0, '0,15 x 200 = 30.'),
  Q('Planet terdekat dari Matahari?', ['Venus', 'Bumi', 'Merkurius'], 2, 'Merkurius paling dekat.'),
];

class PracticeView extends StatefulWidget {
  final Color fg, bg;
  const PracticeView({super.key, required this.fg, required this.bg});
  @override
  State<PracticeView> createState() => _PracticeViewState();
}

class _PracticeViewState extends State<PracticeView> {
  final ctrl = TextEditingController();
  int? target;
  int idx = 0, correct = 0;
  bool? lastRight;
  int? picked;
  bool done = false;

  void start() {
    click();
    final v = int.tryParse(ctrl.text);
    if (v == null || v < 10 || v > 100) {
      ctrl.clear();
      return;
    }
    setState(() {
      target = v;
      idx = 0;
      correct = 0;
      picked = null;
      done = false;
    });
  }

  void pick(int i) {
    if (picked != null) return;
    click();
    setState(() {
      picked = i;
      if (i == sampleQs[idx].ans) correct++;
    });
  }

  void next() {
    click();
    setState(() {
      picked = null;
      if (idx + 1 >= sampleQs.length) {
        done = true;
      } else {
        idx++;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final fg = widget.fg;
    if (target == null) {
      return ListView(children: [
        Text('NILAI TARGET (10-100)', style: px(8, fg)),
        const SizedBox(height: 10),
        TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          style: px(10, fg),
          decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.zero, borderSide: BorderSide(color: fg, width: 2)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.zero, borderSide: BorderSide(color: fg, width: 3))),
        ),
        const SizedBox(height: 14),
        GestureDetector(
          onTap: start,
          child: Container(
            padding: const EdgeInsets.all(14),
            color: fg,
            child: Center(child: Text('START', style: px(10, widget.bg))),
          ),
        ),
        const SizedBox(height: 14),
        Text('Jawab sendiri, lalu lihat skormu vs target.', style: px(7, fg)),
      ]);
    }
    if (done) {
      final score = (correct * 100 / sampleQs.length).round();
      final ok = score >= target!;
      return ListView(children: [
        Text('SKOR: $score', style: px(14, fg)),
        const SizedBox(height: 10),
        Text('TARGET: $target', style: px(9, fg)),
        const SizedBox(height: 10),
        Text(ok ? 'TARGET TERCAPAI!' : 'BELUM, COBA LAGI', style: px(9, fg)),
        const SizedBox(height: 16),
        GestureDetector(
            onTap: () {
              click();
              setState(() => target = null);
            },
            child: Container(padding: const EdgeInsets.all(12), color: fg, child: Center(child: Text('ULANGI', style: px(9, widget.bg))))),
      ]);
    }
    final q = sampleQs[idx];
    return ListView(children: [
      Text('SOAL ${idx + 1}/${sampleQs.length}  TARGET $target', style: px(7, fg)),
      const SizedBox(height: 10),
      Text(q.q, style: px(9, fg)),
      const SizedBox(height: 12),
      for (int i = 0; i < q.opts.length; i++)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: GestureDetector(
            onTap: () => pick(i),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  border: Border.all(color: fg, width: 2),
                  color: picked == null
                      ? Colors.transparent
                      : (i == q.ans ? fg : (i == picked ? fg.withOpacity(.25) : Colors.transparent))),
              child: Text(q.opts[i], style: px(8, picked != null && i == q.ans ? widget.bg : fg)),
            ),
          ),
        ),
      if (picked != null) ...[
        Text('PEMBAHASAN: ${q.why}', style: px(7, fg)),
        const SizedBox(height: 10),
        GestureDetector(
            onTap: next,
            child: Container(padding: const EdgeInsets.all(10), color: fg, child: Center(child: Text('LANJUT', style: px(8, widget.bg))))),
      ],
    ]);
  }
}
